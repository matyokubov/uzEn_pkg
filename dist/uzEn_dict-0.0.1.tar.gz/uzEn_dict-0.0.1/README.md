# python package: uz-en_dict
 -> pip install uz-en_dict